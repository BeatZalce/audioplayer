var sketch1 = function( p ) { 

  p.setup = function() {
    song = p.loadSound('Songs/Dare.mp3');
    p.createCanvas(250, 250);
    bg1 = p.loadImage('imagenes/days.jpg');

   
  }

  p.draw = function() {
    p.background(bg1);
  }

}

//___________________________________________________________

var sketch2 = function( z ) { 

  z.setup = function() {
    song2 = z.loadSound('Songs/Thank You.mp3');
    z.createCanvas(250, 250);
    bg2 = z.loadImage('imagenes/dido.jpg');

    
  }

  z.draw = function() {
    z.background(bg2);
  }
  
}

//___________________________________________________________

var sketch3 = function( r ) { 

  r.setup = function() {
    song3 = r.loadSound('Songs/Galway Girl.mp3');
    r.createCanvas(250, 250);
    bg3 = r.loadImage('imagenes/ed.jpg');

    
  }

  r.draw = function() {
    r.background(bg3);
  }
  
}



var myp5 = new p5(sketch1, 'c1');
var myp5 = new p5(sketch2, 'c2');
var myp5 = new p5(sketch3, 'c3');

//__________________________________________

var sketch4 = function(l) { 

  var  amplitude, cnv;

  l.setup = function() {
    cnv = l.createCanvas(100,100);
    amplitude = new p5.Amplitude();

    cnv.mouseClicked(function() {
      if (song.isPlaying() ){
        song.stop();
      } else {
        song.play();
      }
    });
  }


  l.draw = function() {
    l.background(0);
    l.fill(255);
    var level = amplitude.getLevel();
    var size = l.map(level, 0, 1, 0, 200);
    l.ellipse(50, 50, size, size);
  }
}

//__________________________________________

var sketch5 = function(m) { 

  var  amplitude, cnv;

  m.setup = function() {
    cnv = m.createCanvas(100,100);
    amplitude = new p5.Amplitude();

    cnv.mouseClicked(function() {
      if (song2.isPlaying() ){
        song2.stop();
      } else {
        song2.play();
      }
    });
  }

  
  m.draw = function() {
    m.background(0);
    m.fill(139,246,98);
    var level = amplitude.getLevel();
    var size = m.map(level, 0, 1, 0, 200);
    m.ellipse(50, 50, size, size);
  }
}

//__________________________________________

var sketch6 = function(x) { 

  var  amplitude, cnv;

  x.setup = function() {
    cnv = x.createCanvas(100,100);
    amplitude = new p5.Amplitude();

    cnv.mouseClicked(function() {
      if (song3.isPlaying() ){
        song3.stop();
      } else {
        song3.play();
      }
    });
  }

  
  x.draw = function() {
    x.background(0);
    x.fill(152,29,190);
    var level = amplitude.getLevel();
    var size = x.map(level, 0, 1, 0, 200);
    x.ellipse(50, 50, size, size);
  }
}

var myp5 = new p5(sketch4, 'c4');
var myp5 = new p5(sketch5, 'c5');
var myp5 = new p5(sketch6, 'c6');
